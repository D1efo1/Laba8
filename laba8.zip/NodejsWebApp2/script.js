const CryptoJS = require('crypto-js');
const secretKey = 'my_secret_key';

// ��� ���������
function saveUserData(username) {
    const data = JSON.stringify({ username });
    const encryptedData = CryptoJS.AES.encrypt(data, secretKey).toString();
    localStorage.setItem('userData', encryptedData);
}

// ������������
function loadUserData() {
    const encryptedData = localStorage.getItem('userData');
    if (encryptedData) {
        const bytes = CryptoJS.AES.decrypt(encryptedData, secretKey);
        const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
        console.log(decryptedData);
        return { encrypted: encryptedData, decrypted: decryptedData };
    }
    return null;
}
